pamr.fil <- function(eset,labs,fil=TRUE){
#########################################
    ##=== reshape data
    traindat = list(x=exprs(eset),y=labs)

    if(fil){
      ##=== filter genes
      X        = traindat$x
      mads       <- apply(X,1,mad) #mad: median absolute deviation 
      cmad       <- quantile(mads,.25)
      f1         <- pOverA(0.25, quantile(X,.25))      ## 25% of gene-vals are large
      f2         <- function(x) (mad(x) > cmad)        ## cutoff on variation
      ff         <- filterfun(f1, f2)
      keep       <- genefilter(X, ff)
      X          <- X[keep,]
      traindat$x <- X
    }else{
      keep = rep(TRUE,dim(traindat$x)[1])
    }

    ##=== learn classifier
    sig      = pamr.train(traindat) 	# train a nearest shrunken centroid classifier
    sig.cv   = pamr.cv(sig,traindat)	# cross-validate the nearest shrunken centroid classifier
    cands    = sig.cv$error == min(sig.cv$error)
    thresh   = max(sig.cv$threshold[cands])

    ##=== build prediction rule
    rule.env = new.env() # create new environment 
    assign("sig"    , sig   , envir=rule.env)
    assign("thresh" , thresh , envir=rule.env)
    assign("keep"   , keep   , envir=rule.env)
    rule = function(x){
    ###################
        x = x[keep,]
        pamr.predict(sig,as.matrix(x),thresh,type="posterior") # giving prediction information from nearest shrunken centroid fit 
   }
   environment(rule) <- rule.env
  
   return(rule)
}


