"summarize.add" <-
function(abo,probe.effects){
#############################################
  
  inds.all = indexProbes(abo,which="pm")
  if(dim(exprs(abo))[2] != 1) stop("\n error: to many chips \n\n")
  #if(sum( names(inds.all) == names(probe.effects)) != length(probe.effects)) stop("\n error:
  #	names of the probe effects do not match the abo \n\n")
  inds = unlist(inds.all)

  ##=== subtract the probe effects 
  exprs(abo)        =  log2(exprs(abo))   # rma on log2 scale
  exprs(abo)[inds,] =  exprs(abo)[inds,]-unlist(probe.effects)
  ##=== calculate probe-set specific median as chip effect and residuals
  chipfu            =  function(x) median(exprs(abo)[x,])
  resfu             =  function(x) exprs(abo)[x,] - median(exprs(abo)[x,])
  chip.effects      =  unlist(lapply(inds.all,chipfu))
  residuals         =  unlist(lapply(inds.all,resfu ))

  eset = abo
  exprs(eset) = as.matrix(chip.effects)
  preproc(description(eset))$val$residuals = residuals
  return(eset)
}

