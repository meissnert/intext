"normalize.qnt.add" <-
function(abo,qnt.scale){
 ###############################################

  x   = pm(abo)
  ord = sort.list(x)
  pm(abo) = qnt.scale[sort.list(ord)]
  return(abo)

}

