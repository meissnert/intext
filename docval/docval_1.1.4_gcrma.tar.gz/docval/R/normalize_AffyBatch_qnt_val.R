"normalize.AffyBatch.qnt.val" <-
function (abatch, type = c("separate", "pmonly", "mmonly", "together")) 
{
    type <- match.arg(type)
    if ((type == "pmonly") | (type == "separate")) {
        pms  <- unlist(pmindex(abatch))
        noNA <- rowSums(is.na(intensity(abatch)[pms, , drop = FALSE])) == 
            0
       pms <- pms[noNA]         
       # intensity(abatch)[pms, ] <- normalize.quantiles(intensity(abatch)[pms, 
       #     , drop = FALSE], copy = FALSE)
       tmp = normalize.qnt.val(intensity(abatch)[pms,,drop=FALSE])
       intensity(abatch)[pms, ] = tmp$x
       description(abatch)@preprocessing = c(description(abatch)@preprocessing,
       list(val=list(method="rma",mqnts=tmp$mqnts))) 
    }
    if ((type == "mmonly") | (type == "separate")) {
        mms <- unlist(mmindex(abatch))
        noNA <- rowSums(is.na(intensity(abatch)[mms, , drop = FALSE])) == 
            0
        mms <- mms[noNA]
        #intensity(abatch)[mms, ] <- normalize.quantiles(intensity(abatch)[mms, 
        #    , drop = FALSE], copy = FALSE)
        tmp = normalize.qnt.val(intensity(abatch)[mms,,drop=FALSE])
        intensity(abatch)[pms, ] = tmp$x
        description(abatch)@preprocessing = c(description(abatch)@preprocessing,
        list(val=list(method="rma",mqnts=tmp$mqnts))) 
    }
    if (type == "together") {
        pms <- unlist(indexProbes(abatch, "both"))
        #intensity(abatch)[pms, ] <- normalize.quantiles(intensity(abatch)[pms, 
        #    , drop = FALSE], copy = FALSE)
        tmp = normalize.qnt.val(intensity(abatch)[mms,,drop=FALSE])
        intensity(abatch)[pms, ] = tmp$x
        description(abatch)@preprocessing = c(description(abatch)@preprocessing,
        list(val=list(method="rma",mqnts=tmp$mqnts))) 
    }

    return(abatch)
}

