"wrap.val" <-
function(abo,method="vsn", ...)
######################################

{
# if(!exists("summarize.val")) source("./summarize_val.r")
 if(method=="rma")
 {
#   if(!exists("normalize.AffyBatch.quantiles.val")) source("./normalize_quantiles_val.r")
   a.bg   = bg.correct(abo,"rma", ...) # bg.correct-> package 'affy' 
   a.nrm  = normalize.AffyBatch.qnt.val(a.bg,"pmonly")
   eset   = summarize.val(a.nrm)
   return   (eset)
 }
 if(method=="vsn")
 {
 #  if(!exists("normalize.AffyBatch.vsn.val")) source("./normalize_vsn_val.r"      )
   a.nrm  = normalize.AffyBatch.vsn.val(abo, ...)	
   eset   = summarize.val(a.nrm)
   return   (eset)
 }
# gcrma hinzugefügt
 if(method=="gcrma")
 {
   a.bg   = bg.correct.gcrma(abo, ...)
   a.nrm  = normalize.AffyBatch.gcrma.val(a.bg,"pmonly")
   eset   = summarize.val(a.nrm)
   return   (eset)
 }
 stop(" \n please provide a valid method string. thnx. \n")
}

