"vsn.newpars" <-
function(y,mu,c,pstart=NULL){
 ############################################
     ######################
     nll <- function(pars){
     ###################### 

        off = pars[1]
        fac = pars[2]

        z = y*fac + off
        r = (asinh(z) - mu)^2 * 1/(2*c)
        j = log(1/sqrt(1+z^2)*fac) #* (2*c/length(y)

        res = ( sum(r-j))

        return(res)
     }

     #######################
     dnll <- function(pars){
     #######################

       off = pars[1]
       fac = pars[2]
       z   = y*fac + off

       ##=== doff 
       t1   = 1/c * (asinh(z)-mu) * 1/sqrt(1+z^2)
       t2   = -z/(z^2+1)
       doff = sum(t1) - sum(t2)

       ##=== dfac
       t1   = 1/c  * (asinh(z)-mu) * 1/sqrt(z^2+1) * y
       t2   = (off*z+1)/(fac*(z^2+1))
       dfac = sum(t1) - sum(t2)

       return(c(doff,dfac))
    }


     ##=== optimization
     if(is.null(pstart)) pstart = c(0,1)
     ores = optim( par    = pstart       ,
                  fn     = nll        ,
                  gr     = dnll,
                  method = "L-BFGS-B" ,
                  lower  = c(-Inf,.Machine$double.eps^0.5)  ,
                  upper  = c(Inf ,Inf) ,
                  control= list(trace=0))
     pars = ores$par
     return(list(pars=pars,conv=ores$convergence))
 }

