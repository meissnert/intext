"normalize.AffyBatch.vsn.val" <-
function(abatch, subsample=20000, ...){
###########################


    args = list(...)
    if("strata" %in% names(args)) stop("\n sorry, cant handle strata yet...\n")
    ind = unlist(indexProbes(abatch, "pm"))
    if (!is.na(subsample)) {
        if (!is.numeric(subsample))
            stop("'subsample' must be numeric.")
        if (length(ind) > subsample)
            ind = sample(ind, subsample)
    }
	
   vsn2res <- vsn2(intensity(abatch)[ind,], returnData=TRUE, ...)
	
	vsn.scale<-vsn2res
																					
	preproc(description(abatch))$val$method <-"vsn2" 
	preproc(description(abatch))$val$vsn.scale = vsn.scale
	preproc(description(abatch))$val$ind = ind
	
	intensity(abatch) <- 2^(predict(vsn2res, intensity(abatch))) 
	
	return(abatch)
    
}

