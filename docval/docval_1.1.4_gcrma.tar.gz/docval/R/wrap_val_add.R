"wrap.val.add" <-
function(abo,scale,method="vsn")
#################################################

{
 if(!exists("summarize.add")) source("./summarize_val.r")
 if(method=="rma")
 {
    abo.bg  =  bg.correct(abo,"rma")
    abo.nrm =  normalize.qnt.add(abo.bg,scale$mqnts)
    eset    =  summarize.add(abo.nrm,scale$probe.effects)
    return(eset)
 }
 if(!exists("summarize.add")) source("./summarize_val.r")
 if(method=="gcrma")
 {
    abo.bg  =  bg.adjust.gcrma.2(abo)
    abo.nrm =  normalize.qnt.add(abo.bg,scale$mqnts)
    eset    =  summarize.add(abo.nrm,scale$probe.effects)
    return(eset)
 }
 if(method=="vsn")
 { 
    abo.nrm <- normalize.vsn.add(abo.nrm,scale) 
    eset    <-  summarize.add(abo.nrm,scale$probe.effects)
    return(eset)
 }
 stop(" \n please provide a valid method string. thnx. \n")
}

