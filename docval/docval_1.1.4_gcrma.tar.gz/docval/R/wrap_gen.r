
##=== perform rma and vsn
##    in a generic single chip way...

######################################
wrap.gen <- function(abo,method="vsn")
######################################
{

  if(method=="rma")
  {
    expr.set        = abo
    abo.bg          = bg.correct(abo,"rma")
    ##=== no quantiles available
    abo.nrm         = abo.bg  
    plmset          = rmaPLM(abo.nrm, background = FALSE, normalize = FALSE)
    exprs(expr.set) = coefs(plmset)
    return(expr.set)

  }
  if(method=="gcrma")
  {
    expr.set        = abo
    abo.bg          = bg.correct.gcrma(abo)
   ##=== no quantiles available
    abo.nrm         = abo.bg  
    plmset          = rmaPLM(abo.nrm, background = FALSE, normalize = FALSE)
    exprs(expr.set) = coefs(plmset)
    return(expr.set)

  }
  if(method=="vsn")
  {
    expr.set        = abo
    ##=== no estimation possible
    abo.nrm         = abo ; exprs(abo.nrm) = exp(as.matrix(asinh(exprs(abo))))
    plmset          = rmaPLM(abo.nrm, background = FALSE, normalize = FALSE)
    exprs(expr.set) = coefs(plmset)
    return(expr.set)
  }
  stop("\n method not supported \n")
}

