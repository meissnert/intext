
"normalize.vsn.add" <-
function(abo, vsn.scale){	
 #############################################
 
   	abo.norm<-abo # abo:= single external dataset 
		
	vsn2.res<-vsn2(intensity(abo.norm)[vsn.scale$ind,],reference=vsn.scale$vsn.scale) 
	preproc(description(abo.norm))$val$vsn2res = vsn2.res			
	intensity(abo.norm) <- 2^(predict(vsn2.res, intensity(abo.norm))) 

	return (abo.norm)		     
    }

