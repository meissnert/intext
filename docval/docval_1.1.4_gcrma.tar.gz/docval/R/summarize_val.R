"summarize.val" <-
function(abo){
 ###############################

  
   expr.set <- abo
   plmset <- rmaPLM(abo, background = FALSE, normalize = FALSE)# Fit a RMA to Affymetrix Genechip Data as a PLMset 
   exprs(expr.set) = coefs(plmset)
   preproc(description(expr.set))$scale <- "log2"
   preproc(description(expr.set))$rmaPLM.settings <- plmset@model.description$modelsettings
   probe.effects  = coefs.probe(plmset) ##=== safe pars
   preproc(description(expr.set))$val$probe.effects = probe.effects

   return(expr.set)
}

