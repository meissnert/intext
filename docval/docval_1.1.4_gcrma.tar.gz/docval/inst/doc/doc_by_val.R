###################################################
### chunk number 1: 
###################################################
library(docval)
data(willenbrock)


###################################################
### chunk number 2: 
###################################################
abo.w


###################################################
### chunk number 3: 
###################################################
exs.rma  = wrap.val(abo.w[,-10],method="rma")
scl.rma  = preproc(description(exs.rma))$val


###################################################
### chunk number 4: 
###################################################
exs.vsn  = wrap.val(abo.w[,-10],method="vsn")
scl.vsn  = preproc(description(exs.vsn))$val


###################################################
### chunk number 5: 
###################################################
 labs    = ((as.numeric(pData(abo.w)$IMMUN == "T")-1/2)*2)[-10]
 sig.vsn =  pamr.fil(exs.vsn,labs,fil=FALSE) 
 sig.rma =  pamr.fil(exs.rma,labs,fil=FALSE)


###################################################
### chunk number 6: 
###################################################
sig.byval.rma = list(sig=sig.rma, scl=scl.rma)
sig.byval.vsn = list(sig=sig.vsn, scl=scl.vsn)


###################################################
### chunk number 7: 
###################################################
abo.extrnl = abo.w[,10]



###################################################
### chunk number 8: 
###################################################
exs.extrnl.rma = wrap.val.add(abo.extrnl,sig.byval.rma$scl,method="rma")
exs.extrnl.vsn = wrap.val.add(abo.extrnl,sig.byval.vsn$scl,method="vsn")


###################################################
### chunk number 9: 
###################################################
diag.rma = sig.byval.rma$sig(exprs(exs.extrnl.rma))
diag.vsn = sig.byval.vsn$sig(exprs(exs.extrnl.vsn))


