
library(affy)

### some Willenbrock chips
##########################



##==  set directories

dir   = "/nfs/compdiag/molgen/gene_expression/public_datasets/Willenbrock04/"

dir.r = paste(dir,"rawdata/",sep="")
dir.p = paste(dir,"phenotype/",sep="")


##==  read in cel files (willenbrock)

pats  = c(11,56,18,47,51,38,44,21,5,2)
chips = paste(dir.r,"P",pats,"_amp.CEL.gz",sep="")
abo.w = ReadAffy(filenames = chips, verbose = TRUE)


##==  read in pheno data (willenbrock)
pd    = read.table(paste(dir.p,"data.tab",sep=""))
pd    = pd[rownames(pd) %in% paste("P",pats,"_amp",sep=""),]


##==  if needed, shuffle chips
ord          = match(paste(rownames(pd),".CEL.gz",sep=""),colnames(exprs(abo.w))) 
exprs(abo.w) = exprs(abo.w)[,ord]

metadata<-data.frame(labelDescription=colnames(pd))
pD=new("AnnotatedDataFrame",data=pd, varMetadata=metadata)
#pD = new('phenoData', pData = pd, varLabels = as.list(colnames(pd)))

phenoData(abo.w) = pD

save(abo.w, file="data/willenbrock.RData")






